<?php
declare(strict_types=1);

// Admin password (change this to something secure)
define('ADMIN_PASSWORD', 'cdm2024admin');
