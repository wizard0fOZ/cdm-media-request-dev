<footer class="mt-auto border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
  <div class="mx-auto max-w-7xl px-4 py-6">
    <div class="text-center text-xs text-slate-500 dark:text-slate-400">
      Copyright © <?php echo date('Y'); ?> CDM AV & Media, Admin Panel
    </div>
  </div>
</footer>

</body>
</html>
