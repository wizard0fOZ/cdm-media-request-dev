<?php
declare(strict_types=1);

// Admin config – authentication is now user-based via the `users` table.
// See auth.php for role definitions and permission helpers.
